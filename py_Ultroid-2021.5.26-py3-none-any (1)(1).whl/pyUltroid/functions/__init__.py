# Ultroid - UserBot
# Copyright (C) 2020 TeamUltroid
#
# This file is a part of < https://github.com/TeamUltroid/Ultroid/ >
# PLease read the GNU Affero General Public License in
# <https://www.github.com/TeamUltroid/Ultroid/blob/main/LICENSE/>.

from pyUltroid import *

from ..dB.database import Var

DANGER = [
    "SESSION",
    "HEROKU_API",
    "base64",
    "bash",
    "get_me()",
    "phone",
    "REDIS_PASSWORD",
    "load_addons",
    "load_plugins",
    "os.system",
    "sys.stdout",
    "sys.stderr",
    "subprocess",
]
